Course: ECE232 AMR
Assignment: Workshop Assessment 2 
Date: 04/24/2020
Author: Shingirai Dhoro

Academic Honesty Pledge:
"I affirm that I did not give or receive any unauthorized help on this workshop assessment and that all work is my own." -Shingirai Dhoro

How to run:
This package can be run the same way we have been running workshop by doing the following:
	open 2 terminals and type source devel/setup.bash on both
	in one of them enter rosrun wa_two wa_two_node
	in the other ether rosun wa_two wa_two_test

Thank you.

There seem to be an error in about out of range vector. I did not have time to debug it. 

-Shingirai Dhoro

